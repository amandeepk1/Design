import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  toggleSidebar() {
    const elems = document.getElementsByTagName( 'body' );
    for ( let i = 0, l = elems.length; i < l; i++ ) {
        elems[ i ].classList.toggle('sidenav-toggled');
    }
  }
}
