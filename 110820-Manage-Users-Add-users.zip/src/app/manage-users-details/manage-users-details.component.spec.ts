import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageUsersDetailsComponent } from './manage-users-details.component';

describe('ManageUsersDetailsComponent', () => {
  let component: ManageUsersDetailsComponent;
  let fixture: ComponentFixture<ManageUsersDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageUsersDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageUsersDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
