import { Component, OnInit } from '@angular/core';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
interface Food {
  value: string;
  viewValue: string;
}
export interface Fruit {
  name: string;
}
@Component({
  selector: 'app-manage-users-details',
  templateUrl: './manage-users-details.component.html',
  styleUrls: ['./manage-users-details.component.scss']
})
export class ManageUsersDetailsComponent implements OnInit {
  checked = false;
  indeterminate = false;
  labelPosition: 'before' | 'after' = 'after';
  disabled = false;
  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Male'},
    {value: 'pizza-1', viewValue: 'Female'}
  ];
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  fruits: Fruit[] = [
    {name: 'Skill Name'},
    {name: 'Skill Name Text'},
    {name: 'Skill Name'},
    {name: 'Skill Name Text'},
    {name: 'Skill Name'},
    {name: 'Skill Name Long Text'},
  ];

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      this.fruits.push({name: value.trim()});
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  remove(fruit: Fruit): void {
    const index = this.fruits.indexOf(fruit);

    if (index >= 0) {
      this.fruits.splice(index, 1);
    }
  }
  constructor() { }
  toggleUsername() {
    const elems = document.getElementsByClassName( 'userNameBox' );
    for ( let i = 0, l = elems.length; i < l; i++ ) {
        elems[ i ].classList.toggle('showUname');
    }
  }
  ngOnInit() {
  }

}
